using Microsoft.AspNetCore.Mvc;
using PeneiraApi.Models;
using PeneiraApi.Repositories;

namespace PeneiraApi.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class JogadoresController : ControllerBase
    {
        private readonly IJogadorRepository _repository;

        public JogadoresController(IJogadorRepository repository)
        {
            _repository = repository;
        }

        // 1. Cadastrar jogador (POST)
        [HttpPost]
        public IActionResult Cadastrar([FromBody] Jogador jogador)
        {
            if (_repository.BuscarPorCpf(jogador.Cpf) != null)
                return Conflict(new { mensagem = "Já existe um jogador cadastrado com este CPF." });

            jogador.Aprovado = null;
            _repository.Adicionar(jogador);
            return Ok(jogador);
        }

        // 2. Listar jogadores (GET)
        [HttpGet]
        public IActionResult Listar()
        {
            return Ok(_repository.ListarTodos());
        }

        // 3. Registrar resultado na peneira (POST)
        [HttpPost("resultado")]
        public IActionResult RegistrarResultado([FromBody] ResultadoPeneiraRequest request)
        {
            var jogador = _repository.BuscarPorCpf(request.Cpf);

            if (jogador == null)
                return NotFound(new { mensagem = "Jogador não foi encontrado, por isso o resultado não pode ser registrado." });

            if (jogador.Aprovado != null)
                return Conflict(new { mensagem = "O resultado deste jogador já foi registrado." });

            jogador.Aprovado = request.Aprovado;
            return Ok(jogador);
        }

        // 4. Consultar jogadores aprovados (GET)
        [HttpGet("aprovados")]
        public IActionResult ListarAprovados()
        {
            return Ok(_repository.ListarAprovados());
        }
    }
}
