using PeneiraApi.Repositories;

var builder = WebApplication.CreateBuilder(args);

builder.Services.AddControllers();

// Singleton: a mesma lista em memória é usada durante toda a execução da API
builder.Services.AddSingleton<IJogadorRepository, JogadorRepository>();

var app = builder.Build();

app.UseHttpsRedirection();
app.MapControllers();

app.Run();
