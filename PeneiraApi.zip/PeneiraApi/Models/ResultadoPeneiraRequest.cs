namespace PeneiraApi.Models
{
    public class ResultadoPeneiraRequest
    {
        public string Cpf { get; set; } = string.Empty;
        public bool Aprovado { get; set; }
    }
}
